export interface Feedback {
  id: number;
  body: string;
  product: number;
}
