export interface Category {
  id: number,
  name: string,
}

export interface AuthToken {
  token: string;
}

/* export const categories = [
  {
    id: 1,
    name: 'Processors'
  },
  {
    id: 2,
    name: 'Videocards'
  },
  {
    id: 3,
    name: 'Keyboards'
  },
  {
    id: 4,
    name: 'Smartphones'
  },
];
 */
